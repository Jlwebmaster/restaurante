<?php

session_start();

if(isset($_SESSION['correo']))
{

    $usact=$_SESSION['id'];
   $nombres= $_SESSION['nombres'];
   $apellidos= $_SESSION['apellidos'];
   $rol= $_SESSION['rol'];
   $correo= $_SESSION['correo'];
   $contraseña= $_SESSION['contraseña'];

if($rol==1){

?>

<!DOCTYPE html>

<html lang="esp">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Apertura de  caja</title>

    <link rel="stylesheet" href="../css/bootstrap.min.css">

    <script src="https://kit.fontawesome.com/c6faff6f6a.js" crossorigin="anonymous"></script>

</head>

<body>

    <style>

        body{

            background-color: #222;

            color:#fff;

        }

        h3{

            text-align: center;

        }



        #ingresar{

            background-color: blue;

            margin:25px;}

            #regresar{

                background-color: #ffa100;

            }

            a{

                color:white;

            }
            form{
                width:50%;
                height:auto;
                margin-left:auto;
                margin-right:auto;
            }

    </style>



<div class="container">

  <div class="row">

    <div class="col-sm">
        <br>

     <!--- aqui  va  contenido  -->
    

    </div>

    <div class="col-sm-12 ">
    <br><br><br><br>
  <form action="../srv/apertura_caja" method="POST">
  <h3><div  style="display:flex;"><img src="../img/caja.png" alt="caja"  style="max-width:100px;max-height:100px;border-style:solid;border-width:2px;border-color:orangered;"> &nbsp;&nbsp;&nbsp;APERTURA DE CAJA</div></h3>
<br>
  <div class="mb-3">

   
  </div>

  <div class="mb-3">

 <label for="exampleInputEmail1" class="form-label">Saldo en caja</label>

    <input type="text" class="form-control" id='inputFormatoNumerico' placeholder="ingrese el saldo en caja"  aria-describedby="emailHelp"      name="caja"   required>
    <div class="form-group">
    <label for="exampleFormControlTextarea1">Notas</label>
    <textarea  name="notas"  placeholder="ingrese  notas sobre la apertura  del negocio" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
<button type="submit" class="btn btn-secondary"  id="ingresar"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-box-arrow-in-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M10 3.5a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-2a.5.5 0 0 1 1 0v2A1.5 1.5 0 0 1 9.5 14h-8A1.5 1.5 0 0 1 0 12.5v-9A1.5 1.5 0 0 1 1.5 2h8A1.5 1.5 0 0 1 11 3.5v2a.5.5 0 0 1-1 0v-2z"/>
  <path fill-rule="evenodd" d="M4.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H14.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z"/>
</svg>&nbsp;&nbsp;GUARDAR Y CONTINUAR</button>
  </form>

   

    </div>

    <div class="col-sm">

    <!--- aqui  va  contenido -->

    </div>

  </div>

</div>
<script>
            /**
             * Number.prototype.format(n, x, s, c)
             *
             * @param integer n: length of decimal
             * @param integer x: length of whole part
             * @param mixed   s: sections delimiter
             * @param mixed   c: decimal delimiter
             * sample:
             * let numbers = [1, 12, 123, 1234, 12345, 123456, 1234567, 12345.67, 123456.789];
             * console.log(numbers[6].format(0, 3, ',', '.'); output --> 1,234,567
             * console.log(numbers[8].format(2, 3, ',', '.'); output --> 123,456.78
             */
            Number.prototype.format = function(n, x, s, c) {
                let re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
                    num = this.toFixed(Math.max(0, ~~n));
                return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
            };
            // Restricts input for the given textbox to the given inputFilter.
            function setInputFilter(textbox, inputFilter) {
                ["input"].forEach(function(event) {
                    textbox.addEventListener(event, function() {
                        if (this.id === "inputFormatoNumerico") {
                            if (this.value !== "") {
                                let str = this.value;
                                let oldstr= str.substring(0, str.length - 1);
                                let millares = ",";
                                let decimales = ".";
                                str = str.split(millares).join("");
                                if (isNaN(str)) {
                                    this.value = oldstr;
                                } else {
                                    let numero = parseInt(str);
                                    this.value = numero.format(0, 3, millares, decimales);
                                }
                            }
                        }
                    });
                });
            }
            setInputFilter(document.getElementById("inputFormatoNumerico"), function(value) {
                //declare an object RegExp
                let regex = new RegExp(/^-?\d*$/);
                //test the regexp
                return regex.test(value);
            });
        </script>
</body>

</html>



<?php

}
if($rol==2){

echo "<script>
window.location='meseros/'
</script>";

}





}


else{
echo "<script>
alert('no tienes  permiso de estar aqui');
window.location='../'
</script>";

}


?>