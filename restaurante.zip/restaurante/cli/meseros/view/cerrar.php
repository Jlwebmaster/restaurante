<?php
// Iniciar sesión
session_start();

if(isset($_SESSION['correo']))
{

    $usact=$_SESSION['id'];
   $nombres= $_SESSION['nombres'];
   $apellidos= $_SESSION['apellidos'];
   $rol= $_SESSION['rol'];
   $correo= $_SESSION['correo'];
   $contraseña= $_SESSION['contraseña'];


header("location:../../../srv/salir.php");

}






?>