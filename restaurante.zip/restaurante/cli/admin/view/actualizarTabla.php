<?php

require_once ("../../../srv/cnbd.php");
date_default_timezone_set('America/Bogota');
$fecha = date("Y-m-d"); // variable para la fecha en formato año-mes-día
$hora= date("H:i:s"); // variable para la hora en formato hora:minutos:segundos
$sql = "SELECT pedido.*, GROUP_CONCAT(productos.producto,' ','===>',' ', productos.cantidad SEPARATOR '<br>') AS productos, CONCAT(usuarios.nombres, ' ', usuarios.apellidos) AS mesero FROM pedido JOIN productos ON pedido.id = productos.pedido JOIN usuarios ON pedido.mesero = usuarios.id WHERE pedido.estado = 'pendiente' AND pedido.fecha='$fecha' GROUP BY pedido.id ORDER BY pedido.id DESC";
$result = mysqli_query($conexion, $sql);
$data = array();
if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
  }
}
header('Content-Type: application/json');
echo json_encode($data);
?>
