<?php
// Iniciar sesión
/*
session_start();

if(isset($_SESSION['correo']))
{

    $usact=$_SESSION['id'];
   $nombres= $_SESSION['nombres'];
   $apellidos= $_SESSION['apellidos'];
   $rol= $_SESSION['rol'];
   $correo= $_SESSION['correo'];
   $contraseña= $_SESSION['contraseña'];

if($rol==1){
header("location:../../../srv/salir.php");
}
}


*/



?>

<?php

session_start();

if(isset($_SESSION['correo']))
{

    $usact=$_SESSION['id'];
   $nombres= $_SESSION['nombres'];
   $apellidos= $_SESSION['apellidos'];
   $rol= $_SESSION['rol'];
   $correo= $_SESSION['correo'];
   $contraseña= $_SESSION['contraseña'];

if($rol==1){

?>

<!DOCTYPE html>

<html lang="esp">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cierre de  caja</title>

    <link rel="stylesheet" href="../../../css/bootstrap.min.css">

    <script src="https://kit.fontawesome.com/c6faff6f6a.js" crossorigin="anonymous"></script>

</head>

<body>

    <style>

        body{

            background-color: #222;

            color:#fff;

        }

        h3{

            text-align: center;

        }



        #ingresar{

            background-color: blue;

            margin:25px;}

            #regresar{

                background-color: #ffa100;

            }

            a{

                color:white;

            }
            form{
                width:50%;
                height:auto;
                margin-left:auto;
                margin-right:auto;
            }

            thead{
                color:white;

            }
tbody{
    color:white;
}
    </style>



<div class="container">

  <div class="row">

    <div class="col-sm">
        <br>

     <!--- aqui  va  contenido  -->
    

    </div>

    <div class="col-sm-12 ">
      
    <br><br>
    <div class="table-responsive text-center">
<?php

require_once ("../../../srv/cnbd.php");
date_default_timezone_set('America/Bogota');

// obtén la fecha y hora actual en Colombia
$fecha = date('y/m/d');
$sql = "SELECT usuario, SUM(cantidad) as total FROM propinas WHERE fecha='$fecha' GROUP BY usuario";
$result = $conexion->query($sql);


?>
<div class="table-responsive">
<?php
require_once ("../../../srv/cnbd.php");
date_default_timezone_set('America/Bogota');

// Obtén la fecha y hora actual en Colombia
$fecha = date('y/m/d');

// Consulta para obtener los nombres de todos los usuarios
$sql_usuarios = "SELECT * FROM usuarios";
$result_usuarios = $conexion->query($sql_usuarios);

// Crear un array para almacenar los nombres de los usuarios
$usuarios = array();
if ($result_usuarios->num_rows > 0) {
    while ($row = $result_usuarios->fetch_assoc()) {
        $usuarios[$row["id"]] = $row["nombres"] . " " . $row["apellidos"];
    }
}

// Consulta para obtener el total de propinas por usuario
$sql_propinas = "SELECT usuario, SUM(cantidad) as total FROM propinas WHERE fecha='$fecha' GROUP BY usuario";
$result_propinas = $conexion->query($sql_propinas);
?>
<table class="table table-responsive">
    <h6>Propinas Por pagar</h6>
    <thead>
        <tr>
            <th>Usuario</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result_propinas->num_rows > 0) {
            // Mostrar los resultados en la tabla
            while ($row = $result_propinas->fetch_assoc()) {
                $mesero = $row["usuario"];
                $total_propina = $row['total'];

                echo "<tr>";
                if (isset($usuarios[$mesero])) {
                    echo "<td>" . $usuarios[$mesero] . "</td>";
                } else {
                    echo "<td>Usuario desconocido</td>";
                }
                echo "<td>" . number_format($total_propina). "</td>";
                echo "</tr>";
            }
        } else {
            // Mostrar un mensaje si no hay resultados
            echo "<tr><td colspan='2'>No hay resultados.</td></tr>";
        }
        ?>
    </tbody>
</table>
</div>


    </div>
    <br><br>
  <form action="../../../srv/guardar_salir" method="POST">
  <h3><div  style="display:flex;"><img src="../../../img/caja.png" alt="caja"  style="max-width:100px;max-height:100px;border-style:solid;border-width:2px;border-color:orangered;"> &nbsp;&nbsp;&nbsp;CIERRE DE CAJA</div></h3>
<br>
  <div class="mb-3">

   
  </div>

  <div class="mb-3">

  <label for="exampleInputEmail1" class="form-label">Saldo  de apertura</label>
<?php
$sql1 = "SELECT * FROM contabilidad WHERE fecha='$fecha'";

$resultado1 = mysqli_query($conexion, $sql1);

if (mysqli_num_rows($resultado1) > 0) {
    // Recorre los resultados y almacena el saldo de apertura de caja en una variable
    while($row1 = mysqli_fetch_assoc($resultado1)) {
        $saldo_apertura_caja = $row1["saldo_apertura_caja"];
    }
} 

?>
<input type="text" class="form-control" id='inputFormatoNumerico' aria-describedby="emailHelp" value="<?php  echo  number_format( $saldo_apertura_caja); ?>"     name="sapertura"   readonly  required>
<?php
// Hacer la consulta para obtener la suma de valor_cobrar
$sql2 = "SELECT SUM(valor_cobrar) as total FROM pedido WHERE estado='vendido'  AND fecha ='$fecha'";
$resultado2 = $conexion->query($sql2);

// Comprobar si se encontraron resultados
if ($resultado2->num_rows > 0) {
    // Obtener el resultado y guardarlo en una variable
    while($fila2 = $resultado2->fetch_assoc()) {
        $total = $fila2["total"];

    }}
?>

 <label for="exampleInputEmail1" class="form-label">Saldo ventas</label>

<input type="text" class="form-control" id='inputFormatoNumerico' aria-describedby="emailHelp"  value="<?php  echo  number_format( $total); ?>"     name="sventas"   readonly  required>

<label for="exampleInputEmail1" class="form-label">Saldo Propinas</label>

<?php
// Hacer la consulta para obtener la suma de valor_cobrar
$sql3 = "SELECT SUM(cantidad) as total FROM propinas  WHERE  fecha ='$fecha'";
$resultado3 = $conexion->query($sql3);

// Comprobar si se encontraron resultados
if ($resultado3->num_rows > 0) {
    // Obtener el resultado y guardarlo en una variable
    while($fila3 = $resultado3->fetch_assoc()) {
        $total_propinas_suma= $fila3["total"];

    }}
?>

<input type="text"  value="<?php  echo  number_format( $total_propinas_suma); ?>"  class="form-control" id='inputFormatoNumerico'   aria-describedby="emailHelp"      name="spropinas"   readonly  required>

<label for="exampleInputEmail1" class="form-label">Saldo Total</label>
<?php
$saldo_total_suma=$saldo_apertura_caja+$total+$total_propina;

?>
<input type="text" class="form-control" id='inputFormatoNumerico' aria-describedby="emailHelp"  value="<?php  echo  number_format( $saldo_total_suma); ?>"     name="stotal"   readonly  required>
<?php
$saldo_total_resta=$saldo_apertura_caja+$total+$total_propina;

?>

  
    <div class="form-group">
    <label for="exampleFormControlTextarea1">Notas</label>
    <textarea  name="notas"  placeholder="ingrese  notas sobre la apertura  del negocio" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
<button type="submit" class="btn btn-secondary"  id="ingresar"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-box-arrow-in-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M10 3.5a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-2a.5.5 0 0 1 1 0v2A1.5 1.5 0 0 1 9.5 14h-8A1.5 1.5 0 0 1 0 12.5v-9A1.5 1.5 0 0 1 1.5 2h8A1.5 1.5 0 0 1 11 3.5v2a.5.5 0 0 1-1 0v-2z"/>
  <path fill-rule="evenodd" d="M4.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H14.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z"/>
</svg>&nbsp;&nbsp;GUARDAR Y CONTINUAR</button>
  </form>

   

    </div>

    <div class="col-sm">

    <!--- aqui  va  contenido -->

    </div>

  </div>

</div>
<script>
            /**
             * Number.prototype.format(n, x, s, c)
             *
             * @param integer n: length of decimal
             * @param integer x: length of whole part
             * @param mixed   s: sections delimiter
             * @param mixed   c: decimal delimiter
             * sample:
             * let numbers = [1, 12, 123, 1234, 12345, 123456, 1234567, 12345.67, 123456.789];
             * console.log(numbers[6].format(0, 3, ',', '.'); output --> 1,234,567
             * console.log(numbers[8].format(2, 3, ',', '.'); output --> 123,456.78
             */
            Number.prototype.format = function(n, x, s, c) {
                let re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
                    num = this.toFixed(Math.max(0, ~~n));
                return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
            };
            // Restricts input for the given textbox to the given inputFilter.
            function setInputFilter(textbox, inputFilter) {
                ["input"].forEach(function(event) {
                    textbox.addEventListener(event, function() {
                        if (this.id === "inputFormatoNumerico") {
                            if (this.value !== "") {
                                let str = this.value;
                                let oldstr= str.substring(0, str.length - 1);
                                let millares = ",";
                                let decimales = ".";
                                str = str.split(millares).join("");
                                if (isNaN(str)) {
                                    this.value = oldstr;
                                } else {
                                    let numero = parseInt(str);
                                    this.value = numero.format(0, 3, millares, decimales);
                                }
                            }
                        }
                    });
                });
            }
            setInputFilter(document.getElementById("inputFormatoNumerico"), function(value) {
                //declare an object RegExp
                let regex = new RegExp(/^-?\d*$/);
                //test the regexp
                return regex.test(value);
            });
        </script>
</body>

</html>



<?php

}}


?>


