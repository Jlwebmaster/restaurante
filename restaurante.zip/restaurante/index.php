

<!DOCTYPE html>

<html lang="esp">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="https://kit.fontawesome.com/c6faff6f6a.js" crossorigin="anonymous"></script>

    

</head>

<body>

    <style>

        * {

	margin: 0;

	padding: 0;

	box-sizing: border-box;

}

        body{

            background-image: url(img/bg1.jpg);

            background-repeat: no-repeat;
            background-size:cover;
            background.color:gray;

        

        }

        #login{

            width: auto;

            height: auto;

            max-width: 600px;

            margin-right:auto;

            margin-left:auto;

            color:#fff;

            background-color: #222;

            border-style:groove;

            border-color: blue;

            border-width: 1px;

            vertical-align: baseline;



        }

        h3{

            font-family: Verdana, Geneva, Tahoma, sans-serif;

            text-align: center;

        }

        

       

    

        #ingresar{

            background-color:blue;

            margin:25px;
            width:90%;

        }

        #regbar{

            background-color:blue;

        }

       

        #ingreso{

            margin:10px;

        }



        a{

            color:white;

        }

    #registrobar:hover{

            color:orange;

        }

        .contraseña{

            border-right:0;

        }

        
        #regresar{

background-color: blue;
margin-top:30px;
margin-left:30px;

}

a{
text-decoration: none;
color:#fff;

}

    </style>



    <!--contenedor principal-->
   
    <br><br><br><br><br>

<div class="container">
    

    <div id="login"><br>
    <?php  if(isset($_GET['errlog'])){
        $errorlogin=$_GET['errlog'];
        if($errorlogin=="yes"){
echo"<h5  style='color:red;text-align:center;'> Usuario  o Contraseña  Incorrectos , Por Favor Trata  Nuevamente<h5>";}
    }  ?>
<br>
    <h3>MI CUENTA</h3>



 <!--formulario de  login o inicio de secion-->

<form method="POST" action="srv/valus"  id="ingreso">

  <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label "><i class="fa-solid fa-envelope"></i>&nbsp;&nbsp;&nbsp;&nbspCORREO</label>

    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required name="correo">

  </div>

  <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label"><i class="fas fa-key"></i>&nbsp;&nbsp;&nbsp;&nbsp;CONTRASEÑA</label>

    <div  style="display:flex;background-color:white;">

    <input type="password" class="form-control" id="contraseña_login" required  name="contraseña">

    <a  onclick="mostrarcontraseña_login();"><svg xmlns="http://www.w3.org/2000/svg" color="blue" width="32" height="32" fill="currentColor" class="bi bi-eye-slash-fill" viewBox="0 0 16 16">

      <path d="m10.79 12.912-1.614-1.615a3.5 3.5 0 0 1-4.474-4.474l-2.06-2.06C.938 6.278 0 8 0 8s3 5.5 8 5.5a7.029 7.029 0 0 0 2.79-.588zM5.21 3.088A7.028 7.028 0 0 1 8 2.5c5 0 8 5.5 8 5.5s-.939 1.721-2.641 3.238l-2.062-2.062a3.5 3.5 0 0 0-4.474-4.474L5.21 3.089z"/>

      <path d="M5.525 7.646a2.5 2.5 0 0 0 2.829 2.829l-2.83-2.829zm4.95.708-2.829-2.83a2.5 2.5 0 0 1 2.829 2.829zm3.171 6-12-12 .708-.708 12 12-.708.708z"/>

    </svg></a>

    </div>

  </div>

  <button type="submit" class="btn btn-primary"  id="ingresar">INGRESAR</button>
  <br>
   

</form>

  

    </div>

    <script>

 function mostrarcontraseña_login(){

        var tipo = document.getElementById("contraseña_login");

        if(tipo.type == "password"){

            tipo.type = "text";

        }else{

            tipo.type = "password";

        }

    }

   </script>







</div>

</body>

</html>