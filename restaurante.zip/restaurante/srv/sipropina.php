<?php
session_start();

date_default_timezone_set('America/Bogota');

$fecha = date("Y-m-d");
$hora = date("H:i:s");
require_once("cnbd.php");

if (isset($_SESSION['correo'])) {
    $usact = $_SESSION['id'];
    $nombres = $_SESSION['nombres'];
    $apellidos = $_SESSION['apellidos'];
    $rol = $_SESSION['rol'];
    $correo = $_SESSION['correo'];
    $contraseña = $_SESSION['contraseña'];
} else {
    echo "sin permisos";
    exit;
}
if(isset($_GET['estado'])){
  $id_pedido = $_GET['estado'];
  $propina = 0;
  $mesero = $_GET['mesero'];

  
} else {
  echo "Hubo un error";
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <title>Propinas</title>
  </head>
  <body>
    <div class="container">
      <h3>Registro de Propinas</h3>
      <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="input-field" hidden>
          <input name="estado" id="estado" type="number" value="<?php echo $id_pedido ?>" required>
          <label for="estado">estado</label>
        </div>
        <div class="input-field" hidden>
          <input name="mesero" id="mesero" type="number" value="<?php echo $mesero ?>" required>
          <label for="meseri">mesero</label>
        </div>
        <div class="input-field">
          <input id="propina" type="text"   value="0"  name="propina" required>
          <label for="propina">Valor Propina</label>
        </div>
        <button class="btn waves-effect waves-light" type="submit">Registrar Propina</button>
      </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  </body>
</html>

<?php
if (isset($_POST['mesero'])) {
    $id_pedido = $_POST['estado'];
    $propina_llega = $_POST['propina'];

    $propinaint= str_replace(",", "", $propina_llega);

    $propina=intval($propinaint);

    $mesero = $_POST['mesero'];

    $insertpropina = mysqli_query($conexion, "INSERT INTO propinas (usuario, fecha, hora, cantidad) VALUES ('$mesero', '$fecha', '$hora', '$propina')");

    if ($insertpropina) {

            
                // Actualiza el estado del pedido a "Entregado"
                $sql3 = "UPDATE pedido SET fecha='$fecha', hora='$hora', estado='vendido' WHERE id=$id_pedido";
            
                if ($conexion->query($sql3) === TRUE) {
                    header("location: ../cli/admin/view/pedidos_entregados");
                } else {
                    echo "Error al actualizar el estado del pedido: " . $conexion->error;
                }

              }
              else  {echo "no";}
            // Cierra la conexión a la base de datos
            $conexion->close();
       
}
      ?>

<script>
            /**
             * Number.prototype.format(n, x, s, c)
             *
             * @param integer n: length of decimal
             * @param integer x: length of whole part
             * @param mixed   s: sections delimiter
             * @param mixed   c: decimal delimiter
             * sample:
             * let numbers = [1, 12, 123, 1234, 12345, 123456, 1234567, 12345.67, 123456.789];
             * console.log(numbers[6].format(0, 3, ',', '.'); output --> 1,234,567
             * console.log(numbers[8].format(2, 3, ',', '.'); output --> 123,456.78
             */
            Number.prototype.format = function(n, x, s, c) {
                let re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
                    num = this.toFixed(Math.max(0, ~~n));
                return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
            };
            // Restricts input for the given textbox to the given inputFilter.
            function setInputFilter(textbox, inputFilter) {
                ["input"].forEach(function(event) {
                    textbox.addEventListener(event, function() {
                        if (this.id === "propina") {
                            if (this.value !== "") {
                                let str = this.value;
                                let oldstr= str.substring(0, str.length - 1);
                                let millares = ",";
                                let decimales = ".";
                                str = str.split(millares).join("");
                                if (isNaN(str)) {
                                    this.value = oldstr;
                                } else {
                                    let numero = parseInt(str);
                                    this.value = numero.format(0, 3, millares, decimales);
                                }
                            }
                        }
                    });
                });
            }
            setInputFilter(document.getElementById("propina"), function(value) {
                //declare an object RegExp
                let regex = new RegExp(/^-?\d*$/);
                //test the regexp
                return regex.test(value);
            });
        </script>
      