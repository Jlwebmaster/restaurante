<?php



    require("cnbd.php");

    $usuario = $_GET['usuario'];

   

    $limpiar_restrincion=mysqli_query($conexion,"DELETE FROM productos WHERE pedido IN (SELECT id FROM pedido WHERE mesero = $usuario);");

    $query_delete = mysqli_query($conexion, "DELETE FROM usuarios WHERE id = $usuario");

    mysqli_close($conexion);

    header("location: ../cli/admin/view/usuarios");

?>