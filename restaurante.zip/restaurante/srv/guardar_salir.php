<?php
 require_once("cnbd.php");
$mensaje = isset($_POST['mensaje']) ? $_POST['mensaje'] : '';
$saldo_cierre = $_POST['sventas'];
date_default_timezone_set('America/Bogota');
$fecha_actual = date('Y-m-d');

// Actualizar los campos saldo_cierre y mensaje para la fecha actual
$sql = "UPDATE contabilidad SET saldo_cierre = '$saldo_cierre', notas = '$mensaje' WHERE fecha = '$fecha_actual'";

if (mysqli_query($conexion, $sql)) {
    header("location:salir.php");
} else {
    echo "Error al actualizar los campos saldo_cierre y mensaje: " . mysqli_error($conexion);
}

mysqli_close($conexion);

?>
