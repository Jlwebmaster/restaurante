<?php 

require_once "cnbd.php";
date_default_timezone_set('America/Bogota');


// Obtener los valores del formulario
// Consulta SQL para insertar los datos en la tabla
$sql = "INSERT INTO usuarios (nombres, apellidos, rol, correo, contraseña, estado) VALUES (?, ?, ?, ?, ?, ?)";

// Preparar la consulta
$stmt = $conexion->prepare($sql);

// Asignar los parámetros de la consulta
$nombres = $_POST["nombres"];
$apellidos = $_POST["apellidos"];
$rol = $_POST["rol"];
$correo = $_POST["correo"];
$contraseña = md5($_POST["contraseña"]);
$estado = $_POST["estado"];

$stmt->bind_param("ssisss", $nombres, $apellidos, $rol, $correo, $contraseña, $estado);

// Ejecutar la consulta
if ($stmt->execute()) {
header("location: ../cli/admin/view/usuarios");
} else {
    echo "Error al insertar los datos: " . $conexion->error;
}

// Cerrar la conexión
$stmt->close();
$conexion->close();

?>

