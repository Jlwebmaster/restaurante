<?php



    require("cnbd.php");

    $producto = $_GET['producto'];

   

    

    $query_delete = mysqli_query($conexion, "DELETE FROM add_prod_tmp WHERE id = $producto");

    mysqli_close($conexion);

    header("location: ../cli/meseros/view/nuevo_pedido");

?>