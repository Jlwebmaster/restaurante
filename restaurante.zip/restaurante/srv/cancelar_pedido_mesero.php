<?php
session_start();
if(isset($_SESSION['correo']))
{

    $usact=$_SESSION['id'];
   $nombres= $_SESSION['nombres'];
   $apellidos= $_SESSION['apellidos'];
   $rol= $_SESSION['rol'];
   $correo= $_SESSION['correo'];
   $contraseña= $_SESSION['contraseña'];
}

else{
  echo "sin permisos";
}


    require("cnbd.php");

    $query_delete = mysqli_query($conexion, "DELETE FROM add_prod_tmp WHERE mesero = $usact");

    mysqli_close($conexion);

    header("location: ../cli/meseros/view/dashboard");

?>