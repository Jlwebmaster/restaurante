<?php
session_start();
if(isset($_SESSION['correo']))
{
    $usact=$_SESSION['id'];
    $nombres= $_SESSION['nombres'];
    $apellidos= $_SESSION['apellidos'];
    $rol= $_SESSION['rol'];
    $correo= $_SESSION['correo'];
    $contraseña= $_SESSION['contraseña'];
}
else{
    echo "sin permisos";
    exit; // Salir del script si no hay sesión iniciada
}

if (isset($_POST['n_mesa_cli']) && !empty($_POST['n_mesa_cli'])) {
    $n_mesa_cli = $_POST['n_mesa_cli'];
    require_once "cnbd.php";
    date_default_timezone_set('America/Bogota');
    $fecha = date("Y-m-d"); //Obtiene la fecha actual en formato "año-mes-día"
    $hora = date("H:i:s"); //Obtiene la hora actual en formato "hora:minutos:segundos"
    $sql_insert = "INSERT INTO pedido (fecha, hora, n_mesa_cliente, valor_cobrar, mesero, estado) 
                    VALUES ('$fecha', '$hora', '$n_mesa_cli', '0', '$usact', 'pendiente')";

    // Ejecutar la consulta
    if (mysqli_query($conexion, $sql_insert)) {
        $id_pedido = mysqli_insert_id($conexion);

        // Consulta SQL para obtener todos los datos de la tabla add_prod_tmp
        $sql1 = "SELECT * FROM add_prod_tmp WHERE mesero = $usact";

        // Ejecutar la consulta
        $result1 = mysqli_query($conexion, $sql1);

        // Verificar si la consulta retorna resultados
        if (mysqli_num_rows($result1) > 0) {
            $resultado_suma = 0;

            // Recorrer los resultados y guardarlos en variables
            while ($row1 = mysqli_fetch_assoc($result1)) {
                $id = $row1['id'];
                $producto = $row1['producto'];
                $cantidad = $row1['cantidad'];
                $precio_ind = $row1['precio'];
                $pre_total = $row1['pre_total'];
                $id_real_prod = $row1['id_real_prod'];

                // Sumar los precios totales de los productos
                $resultado_suma += $pre_total;

                // Consulta SQL para insertar los datos en la tabla productos
                $sql = "INSERT INTO productos (producto, precio, cantidad, pre_total, id_real_prod, pedido) 
                        VALUES ('$producto', $precio_ind, $cantidad, $pre_total, $id_real_prod, $id_pedido)";

                // Ejecutar la consulta
                if (mysqli_query($conexion, $sql)) {
                    echo "Datos insertados correctamente en la tabla productos";
                } else {
                    echo "Error al insertar los datos: " . mysqli_error($conexion);
                }
            }

            // Actualizar el valor cobrar del pedido con la suma de los precios totales
            $sql_update = "UPDATE pedido SET valor_cobrar = $resultado_suma WHERE id = $id_pedido";

            // Ejecutar la consulta
            if (mysqli_query($conexion, $sql_update)) {
                // Eliminar los datos de la tabla add_prod_tmp correspondientes al mesero actual
                $Sql_delete = mysqli_query($conexion, "DELETE FROM add_prod_tmp WHERE mesero = $usact");

                header("location: ../cli/meseros/view/dashboard");
                exit; // Salir del script después de redireccionar
            }}}} else {

            
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Numero de mesa</title>
    <style>
        /* Estilos para hacer el formulario responsive */
        form {
            max-width: 600px;
            margin: auto;
            padding: 20px;
        }

        label, input {
            display: block;
            width: 100%;
        }

        input[type="submit"] {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <form action="#" method="post">
        <label for="n_mesa_cli">Numero de mesa / nombre del cliente</label>
        <input type="text" name="n_mesa_cli" id="n_mesa_cli" placeholder="Ingrese el numero de mesa o el nombre del cliente"  title="Debes introducir un número de mesa o nombre de usuario"  required oninvalid="this.setCustomValidity('Este campo es obligatorio. Por favor ingrese un número de mesa o un nombre de cliente.')" oninput="this.setCustomValidity('')">
        <input type="submit" value="Continuar">
    </form>
</body>
</html>


<?php 
}
?>