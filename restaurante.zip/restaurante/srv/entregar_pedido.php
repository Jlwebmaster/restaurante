<?php

session_start();

date_default_timezone_set('America/Bogota');

$fecha = date("Y-m-d"); // variable para la fecha en formato año-mes-día
$hora = date("H:i:s"); // variable para la hora en formato hora:minutos:segundos
require_once("cnbd.php");

if (isset($_SESSION['correo'])) {
    $usact = $_SESSION['id'];
    $nombres = $_SESSION['nombres'];
    $apellidos = $_SESSION['apellidos'];
    $rol = $_SESSION['rol'];
    $correo = $_SESSION['correo'];
    $contraseña = $_SESSION['contraseña'];
} else {
    echo "sin permisos";
    exit; // Salir del script si no hay sesión iniciada
}

$id_pedido = $_POST['id'];

$sql = "SELECT id_real_prod, SUM(cantidad) AS cantidad_total FROM productos WHERE pedido = $id_pedido GROUP BY id_real_prod";

$resultado = mysqli_query($conexion, $sql);

if (mysqli_num_rows($resultado) > 0) {
    while ($row = mysqli_fetch_assoc($resultado)) {
        $producto_id = $row['id_real_prod'];
        $cantidad_total = $row['cantidad_total'];

        $sql2 = "UPDATE inventario SET cant_disponible = cant_disponible - $cantidad_total WHERE id = $producto_id";

        if (mysqli_query($conexion, $sql2)) {
            $sqlactualizarexistencia="UPDATE inventario SET estado = 'agotado' WHERE cant_disponible <= 0";
            mysqli_query($conexion, $sqlactualizarexistencia);
         }
         
    }

    // Actualiza el estado del pedido a "Entregado"
    $sql3 = "UPDATE pedido SET fecha='$fecha', hora='$hora', estado='entregado' WHERE id=$id_pedido";

    if ($conexion->query($sql3) === TRUE) {
        header("location: ../cli/admin/view/dashboard");
    } else {
        echo "Error al actualizar el estado del pedido: " . $conexion->error;
    }
} else {
    echo "No se encontraron productos para el pedido con ID $id_pedido";
}

// Cierra la conexión a la base de datos
$conexion->close();

?>
