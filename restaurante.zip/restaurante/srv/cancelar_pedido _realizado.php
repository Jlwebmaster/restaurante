<?php

session_start();

require_once ("cnbd.php");
if(isset($_SESSION['correo']))
{
    $usact=$_SESSION['id'];
    $nombres= $_SESSION['nombres'];
    $apellidos= $_SESSION['apellidos'];
    $rol= $_SESSION['rol'];
    $correo= $_SESSION['correo'];
    $contraseña= $_SESSION['contraseña'];
}
else{
    echo "sin permisos";
    exit; // Salir del script si no hay sesión iniciada
}


$id_pedido =$_POST['id'];

// Actualiza el estado del pedido a "Entregado"
$sql = "UPDATE pedido SET estado = 'cancelado' WHERE id = $id_pedido";

if ($conexion->query($sql) === TRUE) {
    header("location: ../cli/admin/view/dashboard");
} else {
    echo "Error al actualizar el estado del pedido: " . $conexion->error;
}

// Cierra la conexión a la base de datos
$conexion->close();



?>