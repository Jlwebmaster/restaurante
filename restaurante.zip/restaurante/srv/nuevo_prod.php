<?php 

require_once "cnbd.php";
date_default_timezone_set('America/Bogota');


// Obtener los valores del formulario
$nombre = $_POST['nombre'];
$precio = $_POST['precio'];


$precioint= str_replace(",", "", $precio);

 $precioguardar=intval($precioint);

$cantidad = $_POST['cantidad'];
$estado = 'disponible'; // valor por defecto


// Consulta para insertar los valores en la tabla inventario
$sql = "INSERT INTO inventario (producto, precio, cant_disponible, estado)
VALUES ('$nombre', '$precioguardar', '$cantidad', '$estado');
";


if (mysqli_query($conexion, $sql)) {
    echo "<script>alert('El producto se ha guardado en el sistema')
    window.location='../cli/admin/view/inventario'
    </script>";

} else {
    echo "Error al insertar datos: " . mysqli_error($conexion);
}

// Cerrar la conexión
mysqli_close($conexion);


/*
// obtén la fecha y hora actual en Colombia
$fecha = date('y/m/d');
$caja=$_POST['caja'];
$notas=$_POST['notas'];


$cajaint = str_replace(",", "", $caja);

 $cajaguardar=intval($cajaint);


 $query_insert = mysqli_query($conexion, "INSERT INTO contabilidad(fecha,saldo_apertura_caja,ganancias,saldo_cierre,notas) VALUES ('$fecha','$cajaguardar','0','0','$notas')"); 

 if ($query_insert) {

    echo "<script>
    window.location = '../cli/admin/'
    </script>";
    
 }
 
 else{
echo "<script>
alert('no se ha podido aperturar  el negocio por favor trata nuevamente');
window.location = '../cli/'
</script>";

 }
 */

?>