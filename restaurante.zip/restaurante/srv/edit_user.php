<?php 

require_once "cnbd.php";
date_default_timezone_set('America/Bogota');


// Obtener los datos del formulario
$id = $_POST['id'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$rol = $_POST['rol'];
$correo = $_POST['correo'];
$estado = $_POST['estado'];

// Actualizar los datos en la tabla de usuarios
$sql = "UPDATE usuarios SET nombres='$nombres', apellidos='$apellidos', rol=$rol, correo='$correo', estado='$estado' WHERE id=$id";

if ($conexion->query($sql) === TRUE) {
    header("location:../cli/admin/view/usuarios");
} else {
  echo "Error al actualizar los datos: " . $conexion->error;
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);



?>