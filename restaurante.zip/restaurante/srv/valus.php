<?php

      require_once "cnbd.php";

      $correo = mysqli_real_escape_string($conexion, $_POST['correo']);

      $contraseña = md5 (mysqli_real_escape_string($conexion, $_POST['contraseña']));

      session_start();

      $_SESSION['correo']=$correo;

     $query = mysqli_query($conexion, "SELECT * FROM usuarios WHERE  correo LIKE '$correo' AND  contraseña LIKE '$contraseña'");

      mysqli_close($conexion);

     

      

      $resultado = mysqli_num_rows($query);

     if ($resultado > 0) {

      $dato = mysqli_fetch_array($query);

       

      $_SESSION['id'] = $dato['id'];
      $_SESSION['nombres'] = $dato['nombres'];
      $_SESSION['apellidos'] = $dato['apellidos'];
      $_SESSION['rol'] = $dato['rol'];
      $_SESSION['correo'] = $dato['correo'];

      $_SESSION['contraseña'] = $dato['contraseña'];

      

     

      

       // header('location: ../vista/paneladm.php');

       echo "<script>

       window.location= ' ../cli/';

 </script>";



      } else {





        echo "<script>

        window.location= ' ../index?errlog=yes'

  </script>";

       

      

      }

     



?>

