<?php 
session_start();

if(isset($_SESSION['correo'])) {
    require_once "cnbd.php";
    date_default_timezone_set('America/Bogota');

    $fecha = date("Y-m-d"); // variable para la fecha en formato año-mes-día
    $hora= date("H:i:s"); // variable para la hora en formato hora:minutos:segundos

    if(isset($_GET['cantidad']) && !empty($_GET['cantidad']) && $_GET['cantidad'] > 0 && isset($_GET['prodact']) && !empty($_GET['prodact'])) {
        $usact=$_SESSION['id'];
        $nombres= $_SESSION['nombres'];
        $apellidos= $_SESSION['apellidos'];
        $rol= $_SESSION['rol'];
        $correo= $_SESSION['correo'];
        $contraseña= $_SESSION['contraseña'];

        $prodsel=$_GET['prodact'];
        $cantidad=$_GET['cantidad'];

        //buscamos  los  productos  que coincidan con el id
        $sql_prodsel = "SELECT * FROM inventario WHERE id='$prodsel'";
        $result_prodsel= mysqli_query($conexion, $sql_prodsel);

        if (mysqli_num_rows($result_prodsel) > 0) {
            while ($row_prodsel = mysqli_fetch_assoc($result_prodsel)) {
                $id = $row_prodsel['id'];
                $producto = $row_prodsel['producto'];
                $precio= $row_prodsel['precio'];
                $cantstock=$row_prodsel['cant_disponible'];
            }
if($cantstock<$cantidad){

    echo "<script>
    alert (' no puedes realizar un pedido  con mas productos de los que  hay   disponibles en el negocio');
    window.location='../cli/meseros/view/dashboard';
    </script>";
}  else{

    echo "adelante";

$preciototal=$cantidad *$precio;

            // Consulta SQL para insertar los datos en la tabla
            $sql = "INSERT INTO add_prod_tmp (producto, precio, cantidad, pre_total, id_real_prod, mesero) VALUES (?, ?, ?, ?, ?, ?)";

            // Preparar la consulta
            $stmt = $conexion->prepare($sql);

            // Asignar los parámetros de la consulta
            $stmt->bind_param("ssissi", $producto, $precio, $cantidad, $preciototal, $id ,$usact);

            // Ejecutar la consulta
            if ($stmt->execute()) {
                header("Location: ../cli/meseros/view/dashboard.php");
                exit();
            } else {
                echo "Error al insertar los datos: " . $conexion->error;
            }

            // Cerrar la conexión
            $stmt->close();
            $conexion->close();
        } }else {
            header("Location:../cli/meseros/view/dashboard.php?errprod=yes");
            exit();
        }
    } else {
        header("Location:../cli/meseros/view/dashboard.php?errcampvac=yes");
        exit();
    }
} else {
    header("Location: ../index.php");
    exit();
}


?> 