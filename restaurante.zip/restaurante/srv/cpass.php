<?php
// echo "modulo  no disponible en el momento"

require "cnbd.php";
$id=$_POST['id'];

$conactual= md5(mysqli_real_escape_string( $conexion ,$_POST['ncontrasena']));

$conueva= md5 (mysqli_real_escape_string( $conexion ,$_POST['confirmar_contrasena']));





      if ($conactual==$conueva){


    

      //header('location: ../vista/paneladm.php');

      $query = mysqli_query($conexion, "UPDATE usuarios  set contraseña ='$conueva'  WHERE id= '$id';");

 

    

      mysqli_close($conexion);

        ?>







        <?php

      echo "<script>

      alert('la contraseña  se  a  cambiado correctamente  ' );

      window.location= '../cli/admin/view/usuarios';

</script>";


    }

    else{

        echo "<script>

        alert('las  contraseñas no coinciden. verifica que ambos  campos coincidan');

        window.location= '../cli/admin/view/usuarios';

</script>";



     

    }



?>