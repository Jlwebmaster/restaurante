<?php

session_start();

date_default_timezone_set('America/Bogota');

$fecha = date("Y-m-d"); // variable para la fecha en formato año-mes-día
$hora = date("H:i:s"); // variable para la hora en formato hora:minutos:segundos
require_once("cnbd.php");

if (isset($_SESSION['correo'])) {
    $usact = $_SESSION['id'];
    $nombres = $_SESSION['nombres'];
    $apellidos = $_SESSION['apellidos'];
    $rol = $_SESSION['rol'];
    $correo = $_SESSION['correo'];
    $contraseña = $_SESSION['contraseña'];
} else {
    echo "sin permisos";
    exit; // Salir del script si no hay sesión iniciada
}

$id_pedido = $_GET['estado'];


$propina =0;



    // Actualiza el estado del pedido a "Entregado"
    $sql3 = "UPDATE pedido SET fecha='$fecha', hora='$hora', estado='vendido' WHERE id=$id_pedido";

    if ($conexion->query($sql3) === TRUE) {
        header("location: ../cli/admin/view/pedidos_entregados");
    } else {
        echo "Error al actualizar el estado del pedido: " . $conexion->error;
    }

// Cierra la conexión a la base de datos
$conexion->close();

?>
