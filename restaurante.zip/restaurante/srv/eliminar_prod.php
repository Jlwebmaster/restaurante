<?php

session_start();


if(isset($_SESSION['correo']))
{
    $usact = $_SESSION['id'];
    $nombres = $_SESSION['nombres'];
    $apellidos = $_SESSION['apellidos'];
    $rol = $_SESSION['rol'];
    $correo = $_SESSION['correo'];
    $contraseña = $_SESSION['contraseña'];
}
else {
echo "<script>alert('parece que  no  haces parte de nuestros  empleados, por favor  inicia secion para   poder  hacer uso de nuestro  sistema');
window.location='../index';
</script>";
    exit; // Salir del script si no hay sesión iniciada
}

    require("cnbd.php");

    $producto = $_GET['prodact'];

   

    

    $query_delete = mysqli_query($conexion, "DELETE FROM inventario WHERE id = $producto");

    mysqli_close($conexion);

    header("location: ../cli/admin/view/inventario");

?>